# Basketball Bench Balancer

A sophisticated web application that provides real-time basketball substitution management using an advanced hybrid algorithm to ensure equal playing time while maintaining optimal game flow.

## Overview

The Basketball Bench Balancer is designed for youth basketball coaches who need to manage player rotations fairly and efficiently. The application uses a preventative, urgency-based algorithm that automatically determines optimal substitution timing and player counts to minimize playing time variance while respecting realistic game flow constraints.

## Key Features

### 🎯 **Intelligent Substitution Management**
- **Hybrid Algorithm**: Dynamically determines whether to make 1, 2, or (in extreme cases) 3 player substitutions
- **Preventative Batching**: Anticipates fatigue and readiness needs to batch substitutions efficiently
- **Adaptive Gap Constraints**: Maintains minimum 2-minute gaps between substitutions (adaptive to game length)
- **Real-time Variance Control**: Continuously monitors and optimizes playing time distribution

### ⚙️ **Coach Configuration**
- **Ideal Shifts per Player**: Choose 3-6 shifts with live preview of strategy impact
- **Game Format**: Support for halves or quarters
- **Flexible Roster**: 5-15 players with position assignments and jersey numbers
- **Variance Threshold**: Automatic optimization with tempo-based adjustments

### 📊 **Advanced Analytics**
- **4-Value Fatigue Tracking**: Monitors total playing time, current court stint, current bench stint, and total bench time
- **Real-time Variance Display**: Shows current standard deviation of playing time
- **Predictive Planning**: Preview rotation strategies before game starts
- **Performance Metrics**: Track substitution efficiency and balance

## Algorithm Architecture

### Core Algorithm: Hybrid Preventative System

The application uses a sophisticated multi-tier decision system:

```
Every 15 seconds:
1. Calculate 4-value fatigue scores for all players
2. Check gap constraints (minimum 2 minutes between substitutions)
3. Apply preventative batching logic:
   - If gap constraint would be violated → Batch all pending needs immediately
   - If urgent fatigue detected → Handle immediately with appropriate player count
   - If variance exceeds threshold → Make corrective substitution
   - Otherwise → Wait for optimal timing
```

### Enhanced Fatigue System (4-Value Tracking)

Each player is continuously monitored across four dimensions:

1. **Total Playing Time**: Cumulative minutes on court
2. **Current Court Stint**: Duration of current playing period (max 7 minutes for 30-min games)
3. **Current Bench Stint**: Duration of current rest period
4. **Total Bench Time**: Cumulative minutes on bench

These values feed into composite scoring algorithms that prioritize:
- **Most fatigued court players** for substitution (when approaching 7-minute limit)
- **Most rested and ready bench players** for entry
- **Optimal variance reduction** through strategic pairing

**Prorated Fatigue Limits:**
- Ensures consistent fatigue management across different game lengths
- Prevents gap constraint conflicts by spacing out urgency events
- Maintains player safety while optimizing game flow

### Adaptive Constraints

#### Gap Management
- **Standard Games**: `minGap = gameLength / 15` (e.g., 2 minutes for 30-minute games)
- **Final 10%**: Gap reduces to 45 seconds for balance corrections
- **Halftime**: No constraints, 0-5 player changes allowed
- **Gap Override**: Only when 2+ players exceed maximum court stint (critical fatigue)

#### Substitution Limits
- **Normal Play**: Maximum 2 players per substitution
- **Extreme Cases**: Up to 3 players when multiple urgent situations exist
- **Halftime**: Up to 5 players for tactical adjustments

#### Fatigue Management
- **Max Court Stint**: Prorated to 7 minutes for 30-minute games
  - 20-minute game: 4.67 minutes max stint
  - 30-minute game: 7.00 minutes max stint
  - 40-minute game: 9.33 minutes max stint
- **Prevents Gap Conflicts**: Longer stints reduce fatigue frequency, allowing gap constraints to work effectively

### Preventative vs Reactive Logic

**Traditional Approach (Reactive):**
```
Wait for problems → React when critical → Multiple disruptions
```

**New Approach (Preventative):**
```
Detect approaching problems → Batch solutions → Single efficient disruption
```

This prevents scenarios like "4 substitutions in 45 seconds" by anticipating needs and handling them proactively.

## Codebase Structure

### Core Files

#### `basketball-interval-optimizer.js` (Main Algorithm)
- **BasketballIntervalOptimizer**: Main algorithm class
- **Hybrid decision engine**: `checkForSubstitutions()`
- **4-value fatigue tracking**: Enhanced player state management
- **Preventative batching**: Smart substitution grouping
- **Gap constraint system**: Realistic timing management

#### `basketball-game-engine.js` (Game Management)
- **Real-time game state tracking**
- **Timer management and period control**
- **Player position tracking (court/bench)**
- **Deviation handling and replanning**

#### `basketball-ui-manager.js` (User Interface)
- **Real-time court visualization** with player positions
- **Live statistics display** (variance, playing time, stints)
- **Countdown timers** for next substitutions
- **Visual indicators** for urgent/ready players

#### `basketball-setup-manager.js` (Configuration)
- **Player roster setup** with names and jersey numbers
- **Game format configuration** (halves/quarters, duration)
- **Strategy selection** (ideal shifts per player)
- **Preliminary plan preview** with variance estimation

#### `basketball-integration-main.js` (Orchestration)
- **Component coordination**
- **Event handling and state synchronization**
- **Error handling and recovery**

#### `court.html` (Application Shell)
- **Modern responsive UI** with basketball court visualization
- **Real-time player tracking** with position indicators
- **Configuration interface** with live previews
- **Game controls** and emergency management

### Data Flow

```
1. Setup Manager → Game Configuration
2. Interval Optimizer → Rotation Planning
3. Game Engine → Real-time Execution
4. UI Manager → Visual Updates
5. Integration Main → State Coordination
```

## Algorithm Behavior Examples

### Standard Substitution Flow (with Gap Constraint)
```
03:15 - Urgent: Player A fatigued → Single substitution
⏱️  WAITING: Gap constraint active (0:45/2:00)
⏱️  WAITING: Gap constraint active (1:30/2:00)
05:30 - Variance: High imbalance → Corrective substitution
⏱️  WAITING: Gap constraint active (1:15/2:00)
⚠️  GAP OVERRIDE: 2 urgent players, gap: 1:45
07:45 - Gap-override: Critical fatigue → Double substitution
```

### Preventative Batching Example
```
Without batching:
- 03:15: Player A off, Player X on
- 03:30: Player B off, Player Y on
- 03:45: Player C off, Player Z on
= 3 disruptions in 30 seconds

With preventative batching:
- 03:15: Players A,B,C off → Players X,Y,Z on
= 1 disruption handling all needs
```

### Gap Constraint Benefits
```
Old algorithm: 28 substitutions in 30 minutes (every 64 seconds)
New algorithm: ≤15 substitutions in 30 minutes (≥2 minute gaps)
= 47% fewer disruptions with better balance

Gap Constraint Enforcement:
- 7-minute max court stints prevent frequent fatigue overrides
- 2-minute minimum gaps maintained except for critical situations
- "WAITING" periods show active gap constraint management
- Gap overrides only occur with multiple critical fatigue cases
```

## Configuration Guide

### Ideal Shifts Selection
- **3 Shifts**: Longer stints, less disruption, players develop rhythm
- **4 Shifts**: Balanced approach, good mix of rest and rhythm
- **5 Shifts**: Frequent rotation, maximum equality, everyone stays fresh
- **6 Shifts**: Constant movement, perfect equality, high disruption

### Variance Targets
- **≤60 seconds**: Excellent balance
- **61-90 seconds**: Good balance (default threshold)
- **91-120 seconds**: Marginal balance
- **>120 seconds**: Poor balance, system will intervene

## Technical Requirements

- **Modern web browser** with JavaScript ES6+ support
- **No server required** - runs entirely client-side
- **Responsive design** - works on tablets and larger screens
- **Real-time performance** - 15-second check intervals

## Usage

1. **Setup**: Configure game format, roster, and strategy
2. **Preview**: Review preliminary rotation plan and variance estimates
3. **Execute**: Start game and monitor real-time substitution recommendations
4. **Manage**: Handle deviations with emergency substitutions and player management
5. **Analyze**: Review final statistics and balance metrics

## Future Enhancements

- **Machine learning integration** for personalized fatigue models
- **Historical performance tracking** across multiple games
- **Advanced analytics dashboard** with trend analysis
- **Integration with game statistics** for performance correlation
- **Multi-team tournament management** capabilities

---

*Developed for youth basketball coaches who prioritize fair play, player development, and strategic game management.*