console.log('test'.replace(/\\/g, '\\\\'));
