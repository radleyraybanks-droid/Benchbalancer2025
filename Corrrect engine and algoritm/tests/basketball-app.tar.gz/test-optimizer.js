/**
 * Test script for Basketball Interval Optimizer
 * Tests consistency and balance with the user's setup
 */

const BasketballIntervalOptimizer = require('./basketball-interval-optimizer.js');

// Test configuration matching user's setup
const testConfig = {
    totalPlayers: 8,
    courtSpots: 5,
    gameLength: 1800, // 15 minutes per half
    subsPerRotation: 1,
    minRotationGapSec: 120
};

console.log('🏀 Testing Basketball Interval Optimizer');
console.log('Configuration:', testConfig);
console.log('');

// Initialize optimizer
const optimizer = new BasketballIntervalOptimizer(testConfig);

// Test players
const players = ['Player 1', 'Player 2', 'Player 3', 'Player 4', 'Player 5', 'Reserve 1', 'Reserve 2', 'Reserve 3'];
optimizer.initialize(players);

// Run a single detailed test
console.log('Running detailed analysis...\n');

const plan = optimizer.generatePlan(0, []);

console.log('Final Results:');
console.log(`  Variance: ${plan.expectedVariance} seconds`);
console.log(`  Rotations: ${plan.rotations.length}`);
console.log(`  Target Minutes: ${plan.targetMinutes}`);
console.log('');

// Analyze player distribution
const playerMinutes = plan.playerMinutes;
const sortedPlayers = Object.entries(playerMinutes).sort((a, b) => b[1] - a[1]);

console.log('Player Minutes (sorted by most play time):');
sortedPlayers.forEach(([player, minutes]) => {
    const diff = minutes - plan.targetMinutes;
    const status = diff > 1 ? '🔴' : diff < -1 ? '🔵' : '🟢';
    console.log(`  ${status} ${player}: ${minutes} min (${diff > 0 ? '+' : ''}${diff.toFixed(1)})`);
});

console.log('\nRotation Analysis:');
const targetSeconds = (1800 * 5) / 8; // 1125 seconds
console.log(`Target per player: ${Math.round(targetSeconds)} seconds (${plan.targetMinutes} minutes)`);

let totalVariance = 0;
Object.entries(playerMinutes).forEach(([player, minutes]) => {
    const actualSeconds = minutes * 60;
    const variance = Math.abs(actualSeconds - targetSeconds);
    totalVariance += variance;
    console.log(`  ${player}: ${Math.round(actualSeconds)}s (variance: ${Math.round(variance)}s)`);
});

console.log(`\nTotal variance: ${Math.round(totalVariance)} seconds`);
console.log(`Average variance per player: ${Math.round(totalVariance / 8)} seconds`);

console.log('\nRotation Schedule:');
plan.rotations.forEach((rot, idx) => {
    const time = optimizer.formatTime(rot.time);
    console.log(`  ${idx + 1}. ${time} - OFF: [${rot.off.join(', ')}] → ON: [${rot.on.join(', ')}]`);
});

console.log('\n🏀 Detailed analysis completed!');